package tests.bytecode;

public class ReadCodeTest {
  // No-op; manual test
}
