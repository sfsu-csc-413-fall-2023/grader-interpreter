package tests.bytecode;

public class ReadCodeTest {
  // TODO Read requires a manual test
}
